EVO HTML to PDF Library NE for .NET Core x64
============================================

EVO HTML to PDF Library NE for .NET Core x64 can be easily integrated your applications targeting .NET Core or .NET Standard to create PDF documents from HTML pages and strings.

The library can also be used to convert HTML to images, convert HTML to SVG, create, edit and merge PDF documents.
You can see the http://www.evopdf.com/html-to-pdf-converter.aspx product page for a complete list of library features.

The New Edition (NE) version of the library offers additional support for ECMAScript 6,  WOFF 2, HTTP2 and TLS 1.3 standards.

This optimized version of the library is compatible with .NET Core and .NET Standard on Windows 64-bit (x64) platform which offers a larger address space for executing processes, needed when converting very large HTML documents.

For applications targeting .NET Framework on Windows you can use the library from EvoPdf.HtmlToPdf.NE NuGet package and the x64 variant from EvoPdf.HtmlToPdf.NE.x64 NuGet package.

In any .NET application for Linux, macOS, Windows, Azure App Service, Xamarin, UWP and other platforms you can use the cross-platform library from EvoPdf.Client NuGet package.

Main Features
=============

* Create PDF documents from HTML with advanced support for CSS3, SVG, Web Fonts and JavaScript
* Support for ECMAScript 6,  WOFF 2, HTTP2 and TLS 1.3 standards
* Automatically create PDF links, forms, bookmarks and table of contents from HTML tags
* Place the content from multiple HTML documents at any position in PDF pages, headers or footers
* Create JPEG, PNG and Bitmap raster images from HTML documents
* Create high quality SVG vector images from HTML documents
* Create PDF documents with text, graphics, images, headers and footers
* Create PDF documents with security features and digital signatures
* Create interactive PDF documents with forms, internal links, text notes and JavaScript actions
* Edit, stamp and merge PDF documents

Compatibility
=============

EVO HTML to PDF Library NE for .NET Core x64 is compatible with Windows platforms which support .NET Standard 2.0 or above, including the platforms listed below:

* .NET Core 7, 6, 5, .NET Standard 2.0 , .NET Framework 4.6.2 (and above)
* Windows 64-bit (x64)
* Azure Cloud Services and Azure Virtual Machines
* Web, Console and Desktop applications

Getting Started
===============

You can quickly start with the demo applications from the Samples folder of this package or you can integrate the library in your own project.

To start with your own project, first add a reference to library from EvoPdf.HtmlToPdf.NE.NetCore.x64 Nuget package.
Alternatively you can reference the EvoHtmlToPdf_NetCore.dll library directly from the Bin folder, but in this case you also have to manually reference the EvoPdf.HtmlToPdf.NE.NetCore.x64 package dependencies.

After the reference to library was added to your project you are now ready to start writing code to convert HTML to PDF in your .NET application.
You can copy the C# code lines from the section below to create a PDF document from a web page or from a HTML string and save the resulted PDF to a memory buffer for further processing, to a PDF file or send it to browser for download in ASP.NET applications.

C# Code Samples
---------------

At the top of your C# source file add the 'using EvoPdf;' statement to make available the EVO HTML to PDF API for your .NET application.

    // add this using statement at the top of your C# file
    using EvoPdf;

To convert a HTML string or an URL to a PDF file you can use the C# code below.

    // create the converter object in your code where you want to run conversion
    HtmlToPdfConverter converter = new HtmlToPdfConverter();
    
    // convert the HTML string to a PDF file
    converter.ConvertHtmlToFile("<b>Hello World</b> from EVO PDF !", null, "HtmlToFile.pdf");
    
    // convert HTML page from URL to a PDF file
    string htmlPageURL = "http://www.evopdf.com";
    converter.ConvertUrlToFile(htmlPageURL, "UrlToFile.pdf");

To convert a HTML string or an URL to a PDF document in a memory buffer and then save it to a file you can use the C# code below.

    // create the converter object in your code where you want to run conversion
    HtmlToPdfConverter converter = new HtmlToPdfConverter();
    
    // convert a HTML string to a memory buffer
    byte[] htmlToPdfBuffer = converter.ConvertHtml("<b>Hello World</b> from EVO PDF !", null);
    
    // write the memory buffer to a PDF file
    System.IO.File.WriteAllBytes("HtmlToMemory.pdf", htmlToPdfBuffer);
    
    // convert an URL to a memory buffer
    string htmlPageURL = "http://www.evopdf.com";
    byte[] urlToPdfBuffer = converter.ConvertUrl(htmlPageURL);
    
    // write the memory buffer to a PDF file
    System.IO.File.WriteAllBytes("UrlToMemory.pdf", urlToPdfBuffer);

To convert in your ASP.NET Core applications a HTML string or an URL to a PDF document in a memory buffer and then send it for download to browser you can use the C# code below.

    // create the converter object in your code where you want to run conversion
    HtmlToPdfConverter converter = new HtmlToPdfConverter();
    
    // convert a HTML string to a memory buffer
    byte[] htmlToPdfBuffer = converter.ConvertHtml("<b>Hello World</b> from EVO PDF !", null);
    
    FileResult fileResult = new FileContentResult(htmlToPdfBuffer, "application/pdf");
    fileResult.FileDownloadName = "HtmlToPdf.pdf";
    return fileResult;

Free Trial
==========

You can download the full EVO HTML to PDF Converter for .NET Core package from http://www.evopdf.com/download.aspx page of the website.

The package for .NET Core contains the product binaries, a demo Visual Studio project with full C# code for ASP.NET Core targeting .NET Core 6.0 and later versions, the library documentation in CHM format.

You can evaluate the library for free as long as it is needed to ensure that the solution fits your application needs.

Important Notes
---------------

If you cannot view the Help.chm or you get errors when running or building the demo applications then this might be an indication that the files were blocked by Windows and you have to unblock them as described below.

Before extracting the downloaded Zip archive it is recommended to unblock the Zip file in case it was blocked by Windows OS and marked as an Internet download. 
To unblock the file, right click the Zip file in Windows Explorer, choose the 'Properties' menu item from contextual menu and enable the Unblock option if this option is displayed in file properties. 
If you extracted the archive without unblocking the Zip file first, you can still unblock the blocked files (the .dll, .dat, .chm, .resx files) individually following the same procedure described for the Zip file.

Licensing
=========

The EVO PDF Software licenses are perpetual which means they never expire for a version of the product and include free maintenance for the first year. You can find more details about licensing in http://www.evopdf.com/buy.aspx page of the website.

Support
=======

For technical and sales questions or for general inquiries about our software and company you can contact us using the email addresses from http://www.evopdf.com/contact.aspx page of the website.

