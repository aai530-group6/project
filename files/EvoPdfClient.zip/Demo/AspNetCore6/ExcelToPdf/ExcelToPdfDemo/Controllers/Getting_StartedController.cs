﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

using EvoPdfClient;

namespace ExcelToPdfDemo.Controllers
{
    public class Getting_StartedController : Controller
    {
        private readonly IWebHostEnvironment m_hostingEnvironment;
        public Getting_StartedController(IWebHostEnvironment hostingEnvironment)
        {
            m_hostingEnvironment = hostingEnvironment;
        }

        private void SetCurrentViewData()
        {
            ViewData["ContentRootPath"] = m_hostingEnvironment.ContentRootPath + "/wwwroot";
        }

        public IActionResult Index()
        {
            SetCurrentViewData();

            return View();
        }

        [HttpPost]
        public ActionResult ConvertExcelToPdf(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // Create the Excel to PDF converter object
            ExcelToPdfConverter excelToPdfConverter = null;
            if (useTcpService)
                excelToPdfConverter = new ExcelToPdfConverter(serverIP, serverPort);
            else
                excelToPdfConverter = new ExcelToPdfConverter(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                excelToPdfConverter.ServicePassword = servicePassword;

            // Set license key received after purchase to use the converter in licensed mode
            // Leave it not set to use the converter in demo mode
            excelToPdfConverter.LicenseKey = "4218bHp9bHxsemJ8bH99Yn1+YnV1dXVsfA==";

            // PDF Page Options

            // Set PDF page size which can be a predefined size like A4 or a custom size in points 
            // Leave it not set to have a default A4 PDF page
            excelToPdfConverter.PdfDocumentOptions.PdfPageSize = SelectedPdfPageSize(collection["pdfPageSizeDropDownList"]);

            // Set PDF page orientation to Portrait or Landscape
            // Leave it not set to have a default Portrait orientation for PDF page
            excelToPdfConverter.PdfDocumentOptions.PdfPageOrientation = SelectedPdfPageOrientation(collection["pdfPageOrientationDropDownList"]);

            // Set PDF page margins in points or leave them not set to have a PDF page without margins
            excelToPdfConverter.PdfDocumentOptions.LeftMargin = float.Parse(collection["leftMarginTextBox"]);
            excelToPdfConverter.PdfDocumentOptions.RightMargin = float.Parse(collection["rightMarginTextBox"]);
            excelToPdfConverter.PdfDocumentOptions.TopMargin = float.Parse(collection["topMarginTextBox"]);
            excelToPdfConverter.PdfDocumentOptions.BottomMargin = float.Parse(collection["bottomMarginTextBox"]);

            // Excel Content Destination and Spacing Options

            // Set Excel content destination in PDF page
            if (collection["xLocationTextBox"][0].Length > 0)
                excelToPdfConverter.PdfDocumentOptions.X = float.Parse(collection["xLocationTextBox"]);
            if (collection["yLocationTextBox"][0].Length > 0)
                excelToPdfConverter.PdfDocumentOptions.Y = float.Parse(collection["yLocationTextBox"]);
            if (collection["contentWidthTextBox"][0].Length > 0)
                excelToPdfConverter.PdfDocumentOptions.Width = float.Parse(collection["contentWidthTextBox"]);
            if (collection["contentHeightTextBox"][0].Length > 0)
                excelToPdfConverter.PdfDocumentOptions.Height = float.Parse(collection["contentHeightTextBox"]);

            // Set Excel content top and bottom spacing or leave them not set to have no spacing for the Excel content
            excelToPdfConverter.PdfDocumentOptions.TopSpacing = float.Parse(collection["topSpacingTextBox"]);
            excelToPdfConverter.PdfDocumentOptions.BottomSpacing = float.Parse(collection["bottomSpacingTextBox"]);

            // Scaling Options

            // Use this option to fit the Excel content width in PDF page width
            // By default this property is true and the Excel content can be resized to fit the PDF page width
            excelToPdfConverter.PdfDocumentOptions.FitWidth = collection["fitWidthCheckBox"].Count > 0;

            // Use this option to enable the Excel content stretching when its width is smaller than PDF page width
            // This property has effect only when FitWidth option is true
            // By default this property is false and the Excel content is not stretched
            excelToPdfConverter.PdfDocumentOptions.StretchToFit = collection["stretchCheckBox"].Count > 0;

            // Use this option to automatically dimension the PDF page to display the Excel content unscaled
            // This property has effect only when the FitWidth property is false
            // By default this property is true and the PDF page is automatically dimensioned when FitWidth is false
            excelToPdfConverter.PdfDocumentOptions.AutoSizePdfPage = collection["autoSizeCheckBox"].Count > 0;

            // Use this option to fit the Excel content height in PDF page height
            // If both FitWidth and FitHeight are true then the Excel content will resized if necessary to fit both width and height 
            // preserving the aspect ratio at the same time
            // By default this property is false and the Excel content is not resized to fit the PDF page height
            excelToPdfConverter.PdfDocumentOptions.FitHeight = collection["fitHeightCheckBox"].Count > 0;

            // Use this option to render the whole Excel content into a single PDF page
            // The PDF page size is limited to 14400 points
            // By default this property is false
            excelToPdfConverter.PdfDocumentOptions.SinglePage = collection["singlePageCheckBox"].Count > 0;

            // Add Header

            // Enable header in the generated PDF document
            excelToPdfConverter.PdfDocumentOptions.ShowHeader = collection["addHeaderCheckBox"].Count > 0;

            // Draw header elements
            if (excelToPdfConverter.PdfDocumentOptions.ShowHeader)
                DrawHeader(excelToPdfConverter, true);

            // Add Footer

            // Enable footer in the generated PDF document
            excelToPdfConverter.PdfDocumentOptions.ShowFooter = collection["addFooterCheckBox"].Count > 0;

            // Draw footer elements
            if (excelToPdfConverter.PdfDocumentOptions.ShowFooter)
                DrawFooter(excelToPdfConverter, true, true);

            string excelFile = collection["filePathTextBox"];

            // Convert the Excel document to a PDF document
            byte[] outPdfBuffer = excelToPdfConverter.ConvertExcelFile(excelFile);

            // Send the PDF file to browser
            FileResult fileResult = new FileContentResult(outPdfBuffer, "application/pdf");
            fileResult.FileDownloadName = "ExcelToPdf.pdf";

            return fileResult;
        }

        /// <summary>
        /// Draw the header elements
        /// </summary>
        /// <param name="excelToPdfConverter">The Excel to PDF Converter object</param>
        /// <param name="drawHeaderLine">A flag indicating if a line should be drawn at the bottom of the header</param>
        private void DrawHeader(ExcelToPdfConverter excelToPdfConverter, bool drawHeaderLine)
        {
            string headerImagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/logo.jpg";

            // Set the header height in points
            excelToPdfConverter.PdfHeaderOptions.HeaderHeight = 60;

            // Set header background color
            excelToPdfConverter.PdfHeaderOptions.HeaderBackColor = RgbColor.WhiteSmoke;

            // Set logo
            ImageElement headerImage = new ImageElement(5, 5, 100, 50, headerImagePath);
            excelToPdfConverter.PdfHeaderOptions.AddElement(headerImage);

            // Set header text
            TextElement headerText = new TextElement(0, 5, "EVO Excel to PDF Converter ", new PdfFont("Times New Roman", 10, true));
            // Align the text at the right of the footer
            headerText.TextAlign = HorizontalTextAlign.Right;
            // Set text color
            headerText.ForeColor = RgbColor.Navy;
            // Embed the text element font in PDF
            headerText.EmbedSysFont = true;
            // Add the text element to header
            excelToPdfConverter.PdfHeaderOptions.AddElement(headerText);

            if (drawHeaderLine)
            {
                // Calculate the header width based on PDF page size and margins
                float headerWidth = excelToPdfConverter.PdfDocumentOptions.PdfPageOrientation == PdfPageOrientation.Portrait ?
                    excelToPdfConverter.PdfDocumentOptions.PdfPageSize.Width : excelToPdfConverter.PdfDocumentOptions.PdfPageSize.Height -
                            excelToPdfConverter.PdfDocumentOptions.LeftMargin - excelToPdfConverter.PdfDocumentOptions.RightMargin;

                // Calculate header height
                float headerHeight = excelToPdfConverter.PdfHeaderOptions.HeaderHeight;

                // Create a line element for the bottom of the header
                LineElement headerLine = new LineElement(0, headerHeight - 1, headerWidth, headerHeight - 1);

                // Set line color
                headerLine.ForeColor = RgbColor.Gray;

                // Add line element to the bottom of the header
                excelToPdfConverter.PdfHeaderOptions.AddElement(headerLine);
            }
        }

        /// <summary>
        /// Draw the footer elements
        /// </summary>
        /// <param name="excelToPdfConverter">The Excel to PDF Converter object</param>
        /// <param name="addPageNumbers">A flag indicating if the page numbering is present in footer</param>
        /// <param name="drawFooterLine">A flag indicating if a line should be drawn at the top of the footer</param>
        private void DrawFooter(ExcelToPdfConverter excelToPdfConverter, bool addPageNumbers, bool drawFooterLine)
        {
            string footerImagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/logo.jpg";

            // Set the footer height in points
            excelToPdfConverter.PdfFooterOptions.FooterHeight = 60;

            // Set footer background color
            excelToPdfConverter.PdfFooterOptions.FooterBackColor = RgbColor.WhiteSmoke;

            // Set logo
            ImageElement headerImage = new ImageElement(5, 5, 100, 50, footerImagePath);
            excelToPdfConverter.PdfFooterOptions.AddElement(headerImage);

            // Add page numbering
            if (addPageNumbers)
            {
                // Create a text element with page numbering place holders &p; and & P;
                TextElement footerText = new TextElement(0, 30, "Page &p; of &P;  ", new PdfFont("Times New Roman", 10, true));

                // Align the text at the right of the footer
                footerText.TextAlign = HorizontalTextAlign.Right;

                // Set page numbering text color
                footerText.ForeColor = RgbColor.Navy;

                // Embed the text element font in PDF
                footerText.EmbedSysFont = true;

                // Add the text element to footer
                excelToPdfConverter.PdfFooterOptions.AddElement(footerText);
            }

            if (drawFooterLine)
            {
                // Calculate the footer width based on PDF page size and margins
                float footerWidth = excelToPdfConverter.PdfDocumentOptions.PdfPageOrientation == PdfPageOrientation.Portrait ?
                    excelToPdfConverter.PdfDocumentOptions.PdfPageSize.Width : excelToPdfConverter.PdfDocumentOptions.PdfPageSize.Height -
                            excelToPdfConverter.PdfDocumentOptions.LeftMargin - excelToPdfConverter.PdfDocumentOptions.RightMargin;

                // Create a line element for the top of the footer
                LineElement footerLine = new LineElement(0, 0, footerWidth, 0);

                // Set line color
                footerLine.ForeColor = RgbColor.Gray;

                // Add line element to the bottom of the footer
                excelToPdfConverter.PdfFooterOptions.AddElement(footerLine);
            }
        }

        private PdfPageSize SelectedPdfPageSize(string selectedValue)
        {
            switch (selectedValue)
            {
                case "A0":
                    return PdfPageSize.A0;
                case "A1":
                    return PdfPageSize.A1;
                case "A10":
                    return PdfPageSize.A10;
                case "A2":
                    return PdfPageSize.A2;
                case "A3":
                    return PdfPageSize.A3;
                case "A4":
                    return PdfPageSize.A4;
                case "A5":
                    return PdfPageSize.A5;
                case "A6":
                    return PdfPageSize.A6;
                case "A7":
                    return PdfPageSize.A7;
                case "A8":
                    return PdfPageSize.A8;
                case "A9":
                    return PdfPageSize.A9;
                case "ArchA":
                    return PdfPageSize.ArchA;
                case "ArchB":
                    return PdfPageSize.ArchB;
                case "ArchC":
                    return PdfPageSize.ArchC;
                case "ArchD":
                    return PdfPageSize.ArchD;
                case "ArchE":
                    return PdfPageSize.ArchE;
                case "B0":
                    return PdfPageSize.B0;
                case "B1":
                    return PdfPageSize.B1;
                case "B2":
                    return PdfPageSize.B2;
                case "B3":
                    return PdfPageSize.B3;
                case "B4":
                    return PdfPageSize.B4;
                case "B5":
                    return PdfPageSize.B5;
                case "Flsa":
                    return PdfPageSize.Flsa;
                case "HalfLetter":
                    return PdfPageSize.HalfLetter;
                case "Ledger":
                    return PdfPageSize.Ledger;
                case "Legal":
                    return PdfPageSize.Legal;
                case "Letter":
                    return PdfPageSize.Letter;
                case "Letter11x17":
                    return PdfPageSize.Letter11x17;
                case "Note":
                    return PdfPageSize.Note;
                default:
                    return PdfPageSize.A4;
            }
        }

        private PdfPageOrientation SelectedPdfPageOrientation(string selectedValue)
        {
            return (selectedValue == "Portrait") ? PdfPageOrientation.Portrait : PdfPageOrientation.Landscape;
        }
    }
}