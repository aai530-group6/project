﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Hosting;

// Use EVO PDF Namespace
using EvoPdfClient;

namespace EvoHtmlToPdfDemo.Controllers.PDF_Creator
{
    public class PDF_Creator_Image_ElementsController : Controller
    {
        private readonly Microsoft.AspNetCore.Hosting.IWebHostEnvironment m_hostingEnvironment;
        public PDF_Creator_Image_ElementsController(IWebHostEnvironment hostingEnvironment)
        {
            m_hostingEnvironment = hostingEnvironment;
        }

        // GET: PDF_Creator_Image_Elements
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreatePdf(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // Create a PDF document
            Document pdfDocument = null;
            if (useTcpService)
                pdfDocument = new Document(serverIP, serverPort);
            else
                pdfDocument = new Document(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                pdfDocument.ServicePassword = servicePassword;

            // Set license key received after purchase to use the converter in licensed mode
            // Leave it not set to use the converter in demo mode
            pdfDocument.LicenseKey = "4W9+bn19bn5ue2B+bn1/YH98YHd3d3c=";

            // The titles font used to mark various sections of the PDF document
            PdfFont titleFont = new PdfFont("Times New Roman", 12, true);
            titleFont.Bold = true;
            PdfFont subtitleFont = new PdfFont("Times New Roman", 8, true);
            subtitleFont.Bold = true;

            // Create a PDF page in PDF document
            PdfPage pdfPage = pdfDocument.AddPage();

            // Add section title
            TextElement titleTextElement = new TextElement(5, 5, "Images Scaling", titleFont);
            titleTextElement.ForeColor = RgbColor.Black;
            pdfPage.AddElement(titleTextElement);

            // Add an unscaled image

            // Add section title
            TextElement subtitleTextElement = new TextElement(0, 0, "Unscaled small image with normal resolution", subtitleFont);
            subtitleTextElement.ForeColor = RgbColor.Navy;
            pdfDocument.AddElement(subtitleTextElement, 10);

            string imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/picture_small.jpg";
            ImageElement unscaledImageElement = new ImageElement(0, 0, imagePath);
            pdfDocument.AddElement(unscaledImageElement, 10);

            // Add a large image scaled down to same size in PDF

            // Add section title
            subtitleTextElement = new TextElement(0, 0, "Scaled down large image has higher resolution", subtitleFont);
            subtitleTextElement.ForeColor = RgbColor.Navy;
            pdfDocument.AddElement(subtitleTextElement, 10);

            imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/picture_large.jpg";
            ImageElement scaledDownImageElement = new ImageElement(0, 0, 50, imagePath);
            pdfDocument.AddElement(scaledDownImageElement, 10);

            // Add a border around the scaled down image
            RectangleElement borderElement = new RectangleElement(0, 0, 0, 0);
            pdfDocument.AddElement(borderElement);

            // Add an unscaled small image

            // Add section title
            subtitleTextElement = new TextElement(0, 0, "Unscaled small image", subtitleFont);
            subtitleTextElement.ForeColor = RgbColor.Navy;
            pdfDocument.AddElement(subtitleTextElement, 10);

            imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/picture_smaller.jpg";
            unscaledImageElement = new ImageElement(0, 0, imagePath);
            pdfDocument.AddElement(unscaledImageElement, 10);

            // Add an enlarged image

            // Add section title
            subtitleTextElement = new TextElement(0, 0, "Enlarged small image has lower resolution", subtitleFont);
            subtitleTextElement.ForeColor = RgbColor.Navy;
            pdfDocument.AddElement(subtitleTextElement, 10);

            imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/picture_smaller.jpg";
            ImageElement enlargedImageElement = new ImageElement(0, 0, 200, imagePath);
            // Allow the image to be enlarged
            enlargedImageElement.EnlargeEnabled = true;
            pdfDocument.AddElement(enlargedImageElement, 10);

            // Scale an image preserving the aspect ratio

            // Add section title
            subtitleTextElement = new TextElement(0, 0, "Scaled down image preserving aspect ratio", subtitleFont);
            subtitleTextElement.ForeColor = RgbColor.Navy;
            pdfDocument.AddElement(subtitleTextElement, 10);

            imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/landscape.jpg";
            ImageElement keepAspectImageElement = new ImageElement(0, 0, 80, 80, true, imagePath);
            pdfDocument.AddElement(keepAspectImageElement, 10);

            borderElement = new RectangleElement(0, 0, 0, 0);
            borderElement.ForeColor = RgbColor.Black;
            pdfDocument.AddElement(borderElement);

            // Scale an image without preserving aspect ratio
            // This can produce a distorted image

            // Add section title
            subtitleTextElement = new TextElement(0, 0, "Scaled down image without preserving aspect ratio", subtitleFont);
            subtitleTextElement.ForeColor = RgbColor.Navy;
            pdfDocument.AddElement(subtitleTextElement, 10);

            imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/landscape.jpg";
            ImageElement notKeepAspectImageElement = new ImageElement(0, 0, 80, 80, false, imagePath);
            pdfDocument.AddElement(notKeepAspectImageElement, 10);

            borderElement = new RectangleElement(0, 0, 0, 0);
            borderElement.ForeColor = RgbColor.Black;
            pdfDocument.AddElement(borderElement);

            // Add transparent images

            // Add section title
            titleTextElement = new TextElement(0, 0, "Transparent Images", titleFont);
            titleTextElement.ForeColor = RgbColor.Black;
            pdfDocument.AddElement(titleTextElement, 10);

            imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/transparent.png";
            ImageElement trasparentImageElement = new ImageElement(0, 0, 150, imagePath);
            pdfDocument.AddElement(trasparentImageElement, 10);

            imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/rose.png";
            trasparentImageElement = new ImageElement(0, 0, 150, imagePath);
            pdfDocument.AddElement(trasparentImageElement, 10);

            // Rotate images

            // Add a new page to document
            pdfPage = pdfDocument.AddPage();

            // Add section title
            titleTextElement = new TextElement(0, 0, "Rotated Images", titleFont);
            titleTextElement.ForeColor = RgbColor.Black;
            pdfPage.AddElement(titleTextElement);

            // Add a not rotated image
            imagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/compass.png";
            ImageElement noRotationImageElement = new ImageElement(0, 25, 125, imagePath);
            pdfPage.AddElement(noRotationImageElement);

            // The rotated coordinates system location
            float rotatedImageXLocation = 125;
            float rotatedImageYLocation = 175;

            // Add the image rotated 90 degrees
            ImageElement rotate90ImageElement = new ImageElement(0, 0, 125, imagePath);
            rotate90ImageElement.Translate(rotatedImageXLocation, rotatedImageYLocation);
            rotate90ImageElement.Rotate(90);
            pdfPage.AddElement(rotate90ImageElement);

            rotatedImageXLocation = 125;
            rotatedImageYLocation = 450;

            // Add the image rotated 180 degrees
            ImageElement rotate180ImageElement = new ImageElement(0, 0, 125, imagePath);
            rotate180ImageElement.Translate(rotatedImageXLocation, rotatedImageYLocation);
            rotate180ImageElement.Rotate(180);
            pdfPage.AddElement(rotate180ImageElement);

            rotatedImageXLocation = 0;
            rotatedImageYLocation = 600;

            // Add the image rotated 270 degrees
            ImageElement rotate270ImageElement = new ImageElement(0, 0, 125, imagePath);
            rotate270ImageElement.Translate(rotatedImageXLocation, rotatedImageYLocation);
            rotate270ImageElement.Rotate(270);
            pdfPage.AddElement(rotate270ImageElement);

            // Save the PDF document in a memory buffer
            byte[] outPdfBuffer = pdfDocument.Save();

            // Send the PDF file to browser
            FileResult fileResult = new FileContentResult(outPdfBuffer, "application/pdf");
            fileResult.FileDownloadName = "Image_Elements.pdf";

            return fileResult;
        }
    }
}