﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Hosting;

// Use EVO PDF Namespace
using EvoPdfClient;

namespace EvoHtmlToPdfDemo.Controllers.PDF_Creator
{
    public class PDF_Creator_File_AttachmentsController : Controller
    {
        private readonly Microsoft.AspNetCore.Hosting.IWebHostEnvironment m_hostingEnvironment;
        public PDF_Creator_File_AttachmentsController(IWebHostEnvironment hostingEnvironment)
        {
            m_hostingEnvironment = hostingEnvironment;
        }

        // GET: PDF_Creator_File_Attachments
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreatePdf(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // Create a PDF document
            Document pdfDocument = null;
            if (useTcpService)
                pdfDocument = new Document(serverIP, serverPort);
            else
                pdfDocument = new Document(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                pdfDocument.ServicePassword = servicePassword;

            // Set license key received after purchase to use the converter in licensed mode
            // Leave it not set to use the converter in demo mode
            pdfDocument.LicenseKey = "4W9+bn19bn5ue2B+bn1/YH98YHd3d3c=";

            // Display the attachments panel when the PDF document is opened in a PDF viewer
            pdfDocument.ViewerPreferences.PageMode = ViewerPageMode.UseAttachments;

            // Add a page to PDF document
            PdfPage pdfPage = pdfDocument.AddPage();

            // The titles font used to mark various sections of the PDF document
            PdfFont titleFont = new PdfFont("Times New Roman", 10, true);
            titleFont.Bold = true;
            PdfFont subtitleFont = new PdfFont("Times New Roman", 8, true);

            // Add document title
            TextElement titleTextElement = new TextElement(5, 5, "Attach Files and Streams to a PDF Document", titleFont);
            pdfPage.AddElement(titleTextElement);

            // Create an attachment from a file without icon
            string fileAttachmentPath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Attach_Files/Attachment_File.txt";
            pdfDocument.AddFileAttachment(fileAttachmentPath, "Attachment from File");

            // Create an attachment from a stream without icon
            string fileStreamAttachmentPath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Attach_Files/Attachment_Stream.txt";
            byte[] attachmentData = System.IO.File.ReadAllBytes(fileStreamAttachmentPath);
            pdfDocument.AddFileAttachment(attachmentData, "Attachment_Stream.txt", "Attachment from Stream");

            // Add the text element
            string text = "Click the next icon to open the attachment from a file:";
            TextElement textElement = new TextElement(0, 0, 200, text, subtitleFont);
            pdfDocument.AddElement(textElement, 15);

            // Create an attachment from file with paperclip icon in PDF
            string fileAttachmentWithIconPath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Attach_Files/Attachment_File_Icon.txt";
            // Create the attachment from file
            RectangleFloat attachFromFileIconRectangle = new RectangleFloat(0, 0, 6, 10);
            FileAttachmentElement attachFromFileElement = new FileAttachmentElement(attachFromFileIconRectangle, fileAttachmentWithIconPath);
            attachFromFileElement.IconType = FileAttachmentIcon.Paperclip;
            attachFromFileElement.Text = "Attachment from File with Paperclip Icon";
            attachFromFileElement.IconColor = RgbColor.Blue;
            pdfDocument.AddElement(attachFromFileElement, 10, true, false, 0, true, false);

            // Add the text element
            text = "Click the next icon to open the attachment from a stream:";
            textElement = new TextElement(0, 0, 200, text, subtitleFont);
            pdfDocument.AddElement(textElement, 5, false, 10, true);

            // Create an attachment from stream with pushpin icon in PDF
            string fileStreamAttachmentWithIconPath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Attach_Files/Attachment_Stream_Icon.txt";
            byte[] attachmentDataWithIcon = System.IO.File.ReadAllBytes(fileStreamAttachmentWithIconPath);
            // Create the attachment from stream
            RectangleFloat attachFromStreamIconRectangle = new RectangleFloat(0, 0, 6, 10);
            FileAttachmentElement attachFromStreamElement = new FileAttachmentElement(attachFromStreamIconRectangle, attachmentDataWithIcon, "Attachment_Stream_Icon.txt");
            attachFromStreamElement.IconType = FileAttachmentIcon.PushPin;
            attachFromStreamElement.Text = "Attachment from Stream with Pushpin Icon";
            attachFromStreamElement.IconColor = RgbColor.Green;
            pdfDocument.AddElement(attachFromStreamElement, 10, true, false, 0, true, false);

            // Save the PDF document in a memory buffer
            byte[] outPdfBuffer = pdfDocument.Save();

            // Send the PDF file to browser
            FileResult fileResult = new FileContentResult(outPdfBuffer, "application/pdf");
            fileResult.FileDownloadName = "File_Attachments.pdf";

            return fileResult;
        }
    }
}