﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Hosting;

// Use EVO PDF Namespace
using EvoPdfClient;

namespace EvoHtmlToPdfDemo.Controllers.PDF_Creator
{
    public class PDF_Creator_URI_LinksController : Controller
    {
        private readonly Microsoft.AspNetCore.Hosting.IWebHostEnvironment m_hostingEnvironment;
        public PDF_Creator_URI_LinksController(IWebHostEnvironment hostingEnvironment)
        {
            m_hostingEnvironment = hostingEnvironment;
        }

        // GET: PDF_Creator_URI_Links
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreatePdf(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // Create a PDF document
            Document pdfDocument = null;
            if (useTcpService)
                pdfDocument = new Document(serverIP, serverPort);
            else
                pdfDocument = new Document(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                pdfDocument.ServicePassword = servicePassword;

            // Set license key received after purchase to use the converter in licensed mode
            // Leave it not set to use the converter in demo mode
            pdfDocument.LicenseKey = "4W9+bn19bn5ue2B+bn1/YH98YHd3d3c=";

            // Add a page to PDF document
            PdfPage pdfPage = pdfDocument.AddPage();

            // The titles font used to mark various sections of the PDF document
            PdfFont titleFont = new PdfFont("Times New Roman", 10, true);
            titleFont.Bold = true;
            PdfFont subtitleFont = new PdfFont("Times New Roman", 8, true);

            // The links text font
            PdfFont linkTextFont = new PdfFont("Times New Roman", 8, true);
            linkTextFont.Bold = true;
            linkTextFont.Underline = true;

            // Add document title
            TextElement titleTextElement = new TextElement(5, 5, "Create URI Links in PDF Document", titleFont);
            pdfPage.AddElement(titleTextElement);

            // Make a text in PDF a link to a web page

            // Add the text element
            string text = "Click this text to open a web page!";
            TextElement linkTextElement = new TextElement(0, 0, 150, text, linkTextFont);
            linkTextElement.ForeColor = RgbColor.Navy;
            pdfDocument.AddElement(linkTextElement, 15);

            // Create the URI link element having the size of the text element
            RectangleFloat linkRectangle = RectangleFloat.Empty;
            string url = "http://www.evopdf.com";
            LinkUrlElement uriLink = new LinkUrlElement(linkRectangle, url);

            // Add the URI link to PDF document
            pdfDocument.AddElement(uriLink, 0, true, true, 0, true, false);

            // Make an image in PDF a link to a web page

            TextElement subtitleTextElement = new TextElement(0, 0, "Click the image below to open a web page:", subtitleFont);
            pdfDocument.AddElement(subtitleTextElement, 10);

            // Add the image element
            ImageElement linkImageElement = new ImageElement(0, 0, 120, m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/logo.jpg");
            pdfDocument.AddElement(linkImageElement);

            // Create the URI link element having the size of the image element
            linkRectangle = RectangleFloat.Empty;
            uriLink = new LinkUrlElement(linkRectangle, url);

            // Add the URI link to PDF document
            pdfDocument.AddElement(uriLink, 0, true, true, 0, true, false);

            // Save the PDF document in a memory buffer
            byte[] outPdfBuffer = pdfDocument.Save();

            // Send the PDF file to browser
            FileResult fileResult = new FileContentResult(outPdfBuffer, "application/pdf");
            fileResult.FileDownloadName = "URI_Links.pdf";

            return fileResult;
        }
    }
}