﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

// Use EVO PDF Namespace
using EvoPdfClient;

namespace EvoHtmlToPdfDemo.Controllers.PDF_Creator.PDF_Actions
{
    public class PDF_Creator_Go_To_Page_Open_ActionController : Controller
    {
        [HttpPost]
        public ActionResult CreatePdf(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // Create a PDF document
            Document pdfDocument = null;
            if (useTcpService)
                pdfDocument = new Document(serverIP, serverPort);
            else
                pdfDocument = new Document(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                pdfDocument.ServicePassword = servicePassword;

            // Set license key received after purchase to use the converter in licensed mode
            // Leave it not set to use the converter in demo mode
            pdfDocument.LicenseKey = "4W9+bn19bn5ue2B+bn1/YH98YHd3d3c=";

            // Add a page to PDF document
            PdfPage pdfPage = pdfDocument.AddPage();

            // Create a HTML to PDF element to add to document
            HtmlToPdfElement htmlToPdfElement = new HtmlToPdfElement(collection["urlTextBox"]);

            // Optionally set a delay before conversion to allow asynchonous scripts to finish
            htmlToPdfElement.ConversionDelay = 2;

            // Add the HTML to PDF element to document
            pdfPage.AddElement(htmlToPdfElement);

            int goToPageNumber = int.Parse(collection["pageNumberTextBox"]);

            // Get destination PDF page
            PdfPage goToPage = pdfDocument.GetPage(goToPageNumber - 1);

            // Get the destination point in PDF page
            float goToX = float.Parse(collection["xLocationTextBox"]);
            float goToY = float.Parse(collection["yLocationTextBox"]);

            PointFloat goToLocation = new PointFloat(goToX, goToY);

            // Get the destination view mode
            DestinationViewMode viewMode = SelectedViewMode(collection["viewModeComboBox"]);

            // Create the destination in PDF document
            ExplicitDestination goToDestination = new ExplicitDestination(goToPage, goToLocation, viewMode);

            // Set the zoom level when the destination is displayed
            if (viewMode == DestinationViewMode.XYZ)
                goToDestination.ZoomPercentage = int.Parse(collection["zoomLevelTextBox"]);

            // Set the document Go To open action
            pdfDocument.OpenAction = new PdfActionGoTo(goToDestination);

            // Save the PDF document in a memory buffer
            byte[] outPdfBuffer = pdfDocument.Save();

            // Send the PDF file to browser
            FileResult fileResult = new FileContentResult(outPdfBuffer, "application/pdf");
            fileResult.FileDownloadName = "Go_To_Page_Open_Action.pdf";

            return fileResult;
        }

        private DestinationViewMode SelectedViewMode(string selectedValue)
        {
            switch (selectedValue)
            {
                case "X, Y and Zoom":
                    return DestinationViewMode.XYZ;
                case "Fit Window":
                    return DestinationViewMode.Fit;
                case "Fit Horizontally":
                    return DestinationViewMode.FitH;
                case "Fit Vertically":
                    return DestinationViewMode.FitV;
                default:
                    return DestinationViewMode.XYZ;
            }
        }
    }
}