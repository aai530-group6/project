﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

// Use EVO PDF Namespace
using EvoPdfClient;

namespace EvoHtmlToPdfDemo.Controllers.HTML_to_PDF.PDF_Viewer_Preferences
{
    public class Set_Initial_Zoom_LevelController : Controller
    {
        [HttpPost]
        public ActionResult ConvertHtmlToPdf(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // Create the HTML to PDF converter object
            HtmlToPdfConverter htmlToPdfConverter = null;
            if (useTcpService)
                htmlToPdfConverter = new HtmlToPdfConverter(serverIP, serverPort);
            else
                htmlToPdfConverter = new HtmlToPdfConverter(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                htmlToPdfConverter.ServicePassword = servicePassword;

            // Set license key received after purchase to use the converter in licensed mode
            // Leave it not set to use the converter in demo mode
            htmlToPdfConverter.LicenseKey = "4W9+bn19bn5ue2B+bn1/YH98YHd3d3c=";

            // Set an adddional delay in seconds to wait for JavaScript or AJAX calls after page load completed
            // Set this property to 0 if you don't need to wait for such asynchcronous operations to finish
            htmlToPdfConverter.ConversionDelay = 2;

            // Convert a HTML page to a PDF document object
            Document pdfDocument = htmlToPdfConverter.ConvertUrlToPdfDocumentObject(collection["urlTextBox"]);

            int goToPageNumber = int.Parse(collection["pageNumberTextBox"]);

            // Get destination PDF page
            PdfPage goToPage = pdfDocument.GetPage(goToPageNumber - 1);

            // Get the destination point in PDF page
            float goToX = float.Parse(collection["xLocationTextBox"]);
            float goToY = float.Parse(collection["yLocationTextBox"]);

            PointFloat goToLocation = new PointFloat(goToX, goToY);

            // Get the destination view mode
            DestinationViewMode viewMode = SelectedViewMode(collection["viewModeComboBox"]);

            // Create the destination in PDF document
            ExplicitDestination goToDestination = new ExplicitDestination(goToPage, goToLocation, viewMode);

            // Set the zoom level when the destination is displayed
            if (viewMode == DestinationViewMode.XYZ)
                goToDestination.ZoomPercentage = int.Parse(collection["zoomLevelTextBox"]);

            // Set the document Go To open action
            pdfDocument.OpenAction = new PdfActionGoTo(goToDestination);

            // Save the PDF document in a memory buffer
            byte[] outPdfBuffer = pdfDocument.Save();

            // Send the PDF file to browser
            FileResult fileResult = new FileContentResult(outPdfBuffer, "application/pdf");
            fileResult.FileDownloadName = "Set_Initial_Zoom_Level.pdf";

            return fileResult;
        }

        private DestinationViewMode SelectedViewMode(string selectedValue)
        {
            switch (selectedValue)
            {
                case "X, Y and Zoom":
                    return DestinationViewMode.XYZ;
                case "Fit Window":
                    return DestinationViewMode.Fit;
                case "Fit Horizontally":
                    return DestinationViewMode.FitH;
                case "Fit Vertically":
                    return DestinationViewMode.FitV;
                default:
                    return DestinationViewMode.XYZ;
            }
        }
    }
}