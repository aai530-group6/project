﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

// Use EVO PDF Namespace
using EvoPdfClient;

namespace EvoHtmlToPdfDemo.Controllers
{
    public class Merge_Multiple_HTMLController : Controller
    {
        // GET: Merge_Multiple_HTML
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ConvertHtmlToPdf(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // Create a PDF document
            Document pdfDocument = null;
            if (useTcpService)
                pdfDocument = new Document(serverIP, serverPort);
            else
                pdfDocument = new Document(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                pdfDocument.ServicePassword = servicePassword;

            // Set license key received after purchase to use the converter in licensed mode
            // Leave it not set to use the converter in demo mode
            pdfDocument.LicenseKey = "4W9+bn19bn5ue2B+bn1/YH98YHd3d3c=";

            // Create a PDF page where to add the first HTML
            PdfPage firstPdfPage = pdfDocument.AddPage();

            // Create the first HTML to PDF element
            HtmlToPdfElement firstHtml = new HtmlToPdfElement(0, 0, collection["firstUrlTextBox"]);

            // Optionally set a delay before conversion to allow asynchronous scripts to finish
            firstHtml.ConversionDelay = 2;

            // Add the first HTML to PDF document
            firstPdfPage.AddElement(firstHtml);

            PdfPage secondPdfPage = null;

            // Create the second HTML to PDF element
            HtmlToPdfElement secondHtml = new HtmlToPdfElement(0, 0, collection["secondUrlTextBox"]);

            // Optionally set a delay before conversion to allow asynchronous scripts to finish
            secondHtml.ConversionDelay = 2;

            if (collection["startNewPageCheckBox"].Count > 0)
            {
                // Create a PDF page where to add the second HTML
                secondPdfPage = pdfDocument.AddPage();

                // Add the second HTML to PDF document
                secondPdfPage.AddElement(secondHtml);
            }
            else
            {
                // Add the second HTML right after the first one
                pdfDocument.AddElement(secondHtml);
            }

            // Save the PDF document in a memory buffer
            byte[] outPdfBuffer = pdfDocument.Save();

            // Send the PDF file to browser
            FileResult fileResult = new FileContentResult(outPdfBuffer, "application/pdf");
            fileResult.FileDownloadName = "Merge_Multipe_HTML.pdf";

            return fileResult;
        }
    }
}