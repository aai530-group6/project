﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.Text;

using EvoPdfClient;

namespace PdfToHtmlDemo.Controllers
{
    public class Getting_StartedController : Controller
    {
        private readonly IWebHostEnvironment m_hostingEnvironment;
        public Getting_StartedController(IWebHostEnvironment hostingEnvironment)
        {
            m_hostingEnvironment = hostingEnvironment;
        }

        public IActionResult Index()
        {
            ViewData["DemoFilePath"] = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoFiles/Input/Demo.pdf";

            return View();
        }

        [HttpPost]
        public ActionResult ConvertPdfToHtml(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // the pdf file to convert
            string pdfFilePath = collection["filePathTextBox"][0].Trim();
            if (pdfFilePath.Equals(String.Empty))
                throw new Exception("Please choose a PDF file to convert");

            // start page number
            int startPageNumber = int.Parse(collection["startPageTextBox"][0].Trim());
            // end page number
            // when it is 0 the extraction will continue up to the end of document
            int endPageNumber = 0;
            if (collection["endPageTextBox"][0].Trim() != String.Empty)
                endPageNumber = int.Parse(collection["endPageTextBox"][0].Trim());

            // Create the PDF to HTML converter object
            PdfToHtmlConverter pdfToHtmlConverter = null;
            if (useTcpService)
                pdfToHtmlConverter = new PdfToHtmlConverter(serverIP, serverPort);
            else
                pdfToHtmlConverter = new PdfToHtmlConverter(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                pdfToHtmlConverter.ServicePassword = servicePassword;

            pdfToHtmlConverter.LicenseKey = "1FpLW01LW0tbTVVLW0hKVUpJVUJCQkJbSw==";

            // set the resolution of HTML images
            pdfToHtmlConverter.Resolution = int.Parse(collection["resolutionTextBox"]);

            // set the zoom of HTML content
            pdfToHtmlConverter.Zoom = int.Parse(collection["zoomTextBox"]);

            PdfPageHtml[] pdfPageHtmls = null;
            try
            {
                // read the PDF file in a memory buffer
                byte[] sourcePdfBytes = System.IO.File.ReadAllBytes(pdfFilePath);

                // convert PDF pages in memory to an array of PdfPageHtml objects
                pdfPageHtmls = pdfToHtmlConverter.ConvertPdfPagesToHtml(sourcePdfBytes, startPageNumber, endPageNumber);
            }
            catch (Exception ex)
            {
                // The conversion failed
                throw new Exception(String.Format("An error occurred. {0}", ex.Message));
            }

            byte[] htmlBytes = null;
            try
            {
                // get the HTML document for the first PDF page in range
                htmlBytes = Encoding.UTF8.GetBytes(pdfPageHtmls[0].Html);
            }
            finally
            {
                // dispose the generated HTML documents
                for (int i = 0; i < pdfPageHtmls.Length; i++)
                    pdfPageHtmls[i].Dispose();
            }

            FileResult fileResult = new FileContentResult(htmlBytes, "text/html; charset=UTF-8");
            fileResult.FileDownloadName = "PdfPage.html";

            return fileResult;
        }
    }
}