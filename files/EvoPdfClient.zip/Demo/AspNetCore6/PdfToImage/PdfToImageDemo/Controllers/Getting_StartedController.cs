﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

using EvoPdfClient;

namespace PdfToImageDemo.Controllers
{
    public class Getting_StartedController : Controller
    {
        private readonly IWebHostEnvironment m_hostingEnvironment;
        public Getting_StartedController(IWebHostEnvironment hostingEnvironment)
        {
            m_hostingEnvironment = hostingEnvironment;
        }

        public IActionResult Index()
        {
            ViewData["DemoFilePath"] = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoFiles/Input/Demo.pdf";

            return View();
        }

        [HttpPost]
        public ActionResult ConvertPdfToImage(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // the pdf file to convert
            string pdfFilePath = collection["filePathTextBox"][0].Trim();
            if (pdfFilePath.Equals(String.Empty))
                throw new Exception("Please choose a PDF file to convert");

            // start page number
            int startPageNumber = int.Parse(collection["startPageTextBox"][0].Trim());
            // end page number
            // when it is 0 the extraction will continue up to the end of document
            int endPageNumber = 0;
            if (collection["endPageTextBox"][0].Trim() != String.Empty)
                endPageNumber = int.Parse(collection["endPageTextBox"][0].Trim());

            // Create the PDF to Image converter object
            PdfToImageConverter pdfToImageConverter = null;
            if (useTcpService)
                pdfToImageConverter = new PdfToImageConverter(serverIP, serverPort);
            else
                pdfToImageConverter = new PdfToImageConverter(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                pdfToImageConverter.ServicePassword = servicePassword;

            pdfToImageConverter.LicenseKey = "0F5PX0pGX09fSVFPX0xOUU5NUUZGRkZfTw==";

            // set the color space of the resulted images
            pdfToImageConverter.ColorSpace = SelectedColorSpace(collection["colorSpaceDropDownList"]);

            // set the resolution of the resulted images
            pdfToImageConverter.Resolution = int.Parse(collection["resolutionTextBox"]);

            byte[] imageBytes = null;
            try
            {
                if (collection["multipageTiffCheckBox"].Count > 0)
                {
                    // save the PDF as a multipage TIFF image having a frame for each converted PDF page
                    imageBytes = pdfToImageConverter.ConvertPdfToTiff(pdfFilePath, startPageNumber, endPageNumber);
                }
                else
                {
                    // read the PDF file in a memory buffer
                    byte[] sourcePdfBytes = System.IO.File.ReadAllBytes(pdfFilePath);

                    // convert the PDF pages to images in memory
                    PdfPageImage[] pdfPageImages = pdfToImageConverter.ConvertPdfPagesToImage(sourcePdfBytes, startPageNumber, endPageNumber);

                    if (pdfPageImages.Length == 0)
                        throw new Exception("The images collection is empty");

                    imageBytes = pdfPageImages[0].ImageData;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("An error occurred. {0}", ex.Message));
            }

            FileResult fileResult = null;

            if (collection["multipageTiffCheckBox"].Count > 0)
            {
                fileResult = new FileContentResult(imageBytes, "image/tiff");
                fileResult.FileDownloadName = "pdftoimage.tiff";
            }
            else
            {
                fileResult = new FileContentResult(imageBytes, "image/png");
                fileResult.FileDownloadName = "pdftoimage.png";
            }

            return fileResult;
        }

        private PdfPageImageColorSpace SelectedColorSpace(string colorSpace)
        {
            switch (colorSpace)
            {
                case "RGB":
                    return PdfPageImageColorSpace.RGB;
                case "Mono":
                    return PdfPageImageColorSpace.Mono;
                case "Gray":
                    return PdfPageImageColorSpace.Gray;
                default:
                    return PdfPageImageColorSpace.RGB;
            }
        }
    }
}