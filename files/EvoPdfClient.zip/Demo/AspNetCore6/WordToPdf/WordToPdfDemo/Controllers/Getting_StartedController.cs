﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

using EvoPdfClient;

namespace WordToPdfDemo.Controllers
{
    public class Getting_StartedController : Controller
    {
        private readonly IWebHostEnvironment m_hostingEnvironment;
        public Getting_StartedController(IWebHostEnvironment hostingEnvironment)
        {
            m_hostingEnvironment = hostingEnvironment;
        }

        private void SetCurrentViewData()
        {
            ViewData["ContentRootPath"] = m_hostingEnvironment.ContentRootPath + "/wwwroot";
        }

        public IActionResult Index()
        {
            SetCurrentViewData();

            return View();
        }

        [HttpPost]
        public ActionResult ConvertWordToPdf(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // Create the Word to PDF converter
            WordToPdfConverter wordToPdfConverter = null;
            if (useTcpService)
                wordToPdfConverter = new WordToPdfConverter(serverIP, serverPort);
            else
                wordToPdfConverter = new WordToPdfConverter(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                wordToPdfConverter.ServicePassword = servicePassword;

            // Set license key received after purchase to use the converter in licensed mode
            // Leave it not set to use the converter in demo mode
            wordToPdfConverter.LicenseKey = "0lxNXUtPXU1dS1NNXU5MU0xPU0RERERdTQ==";

            // Word Content Destination and Spacing Options

            // Set Word content destination in PDF page
            if (collection["xLocationTextBox"][0].Length > 0)
                wordToPdfConverter.PdfDocumentOptions.X = float.Parse(collection["xLocationTextBox"]);
            if (collection["yLocationTextBox"][0].Length > 0)
                wordToPdfConverter.PdfDocumentOptions.Y = float.Parse(collection["yLocationTextBox"]);
            if (collection["contentWidthTextBox"][0].Length > 0)
                wordToPdfConverter.PdfDocumentOptions.Width = float.Parse(collection["contentWidthTextBox"]);
            if (collection["contentHeightTextBox"][0].Length > 0)
                wordToPdfConverter.PdfDocumentOptions.Height = float.Parse(collection["contentHeightTextBox"]);

            // Set Word content top and bottom spacing or leave them not set to have no spacing for the Word content
            wordToPdfConverter.PdfDocumentOptions.TopSpacing = float.Parse(collection["topSpacingTextBox"]);
            wordToPdfConverter.PdfDocumentOptions.BottomSpacing = float.Parse(collection["bottomSpacingTextBox"]);

            // Add Header

            // Enable header in the generated PDF document
            wordToPdfConverter.PdfDocumentOptions.ShowHeader = collection["addHeaderCheckBox"].Count > 0;

            // Draw header elements
            if (wordToPdfConverter.PdfDocumentOptions.ShowHeader)
                DrawHeader(wordToPdfConverter, true);

            // Add Footer

            // Enable footer in the generated PDF document
            wordToPdfConverter.PdfDocumentOptions.ShowFooter = collection["addFooterCheckBox"].Count > 0;

            // Draw footer elements
            if (wordToPdfConverter.PdfDocumentOptions.ShowFooter)
                DrawFooter(wordToPdfConverter, true, true);

            string wordFile = collection["filePathTextBox"];

            // Convert the Word document to a PDF document
            byte[] outPdfBuffer = wordToPdfConverter.ConvertWordFile(wordFile);

            // Send the PDF file to browser
            FileResult fileResult = new FileContentResult(outPdfBuffer, "application/pdf");
            fileResult.FileDownloadName = "WordToPdf.pdf";

            return fileResult;
        }

        /// <summary>
        /// Draw the header elements
        /// </summary>
        /// <param name="wordToPdfConverter">The Word to PDF Converter object</param>
        /// <param name="drawHeaderLine">A flag indicating if a line should be drawn at the bottom of the header</param>
        private void DrawHeader(WordToPdfConverter WordToPdfConverter, bool drawHeaderLine)
        {
            string headerImagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/logo.jpg";

            // Set the header height in points
            WordToPdfConverter.PdfHeaderOptions.HeaderHeight = 60;

            // Set header background color
            WordToPdfConverter.PdfHeaderOptions.HeaderBackColor = RgbColor.WhiteSmoke;

            // Set logo
            ImageElement headerImage = new ImageElement(5, 5, 100, 50, headerImagePath);
            WordToPdfConverter.PdfHeaderOptions.AddElement(headerImage);

            // Set header text
            TextElement headerText = new TextElement(0, 5, "EVO Word to PDF Converter ", new PdfFont("Times New Roman", 10, true));
            // Align the text at the right of the footer
            headerText.TextAlign = HorizontalTextAlign.Right;
            // Set text color
            headerText.ForeColor = RgbColor.Navy;
            // Embed the text element font in PDF
            headerText.EmbedSysFont = true;
            // Add the text element to header
            WordToPdfConverter.PdfHeaderOptions.AddElement(headerText);
        }

        /// <summary>
        /// Draw the footer elements
        /// </summary>
        /// <param name="wordToPdfConverter">The Word to PDF Converter object</param>
        /// <param name="addPageNumbers">A flag indicating if the page numbering is present in footer</param>
        /// <param name="drawFooterLine">A flag indicating if a line should be drawn at the top of the footer</param>
        private void DrawFooter(WordToPdfConverter WordToPdfConverter, bool addPageNumbers, bool drawFooterLine)
        {
            string footerImagePath = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoAppFiles/Input/Images/logo.jpg";

            // Set the footer height in points
            WordToPdfConverter.PdfFooterOptions.FooterHeight = 60;

            // Set footer background color
            WordToPdfConverter.PdfFooterOptions.FooterBackColor = RgbColor.WhiteSmoke;

            // Set logo
            ImageElement headerImage = new ImageElement(5, 5, 100, 50, footerImagePath);
            WordToPdfConverter.PdfFooterOptions.AddElement(headerImage);

            // Add page numbering
            if (addPageNumbers)
            {
                // Create a text element with page numbering place holders &p; and & P;
                TextElement footerText = new TextElement(0, 30, "Page &p; of &P;  ", new PdfFont("Times New Roman", 10, true));

                // Align the text at the right of the footer
                footerText.TextAlign = HorizontalTextAlign.Right;

                // Set page numbering text color
                footerText.ForeColor = RgbColor.Navy;

                // Embed the text element font in PDF
                footerText.EmbedSysFont = true;

                // Add the text element to footer
                WordToPdfConverter.PdfFooterOptions.AddElement(footerText);
            }
        }
    }
}