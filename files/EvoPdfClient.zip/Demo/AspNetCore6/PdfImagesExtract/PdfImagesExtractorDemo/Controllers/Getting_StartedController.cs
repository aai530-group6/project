﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

using EvoPdfClient;

namespace PdfImagesExtractorDemo.Controllers
{
    public class Getting_StartedController : Controller
    {
        private readonly IWebHostEnvironment m_hostingEnvironment;
        public Getting_StartedController(IWebHostEnvironment hostingEnvironment)
        {
            m_hostingEnvironment = hostingEnvironment;
        }

        public IActionResult Index()
        {
            ViewData["DemoFilePath"] = m_hostingEnvironment.ContentRootPath + "/wwwroot" + "/DemoFiles/Input/Demo.pdf";

            return View();
        }

        [HttpPost]
        public ActionResult ExtractImages(IFormCollection collection)
        {
            // Get the server options
            string serverIP = collection["textBoxServerIP"];
            uint serverPort = uint.Parse(collection["textBoxServerPort"]);
            string servicePassword = collection["textBoxServicePassword"];
            bool useServicePassword = servicePassword.Length > 0;
            bool useTcpService = collection["ServerType"] == "radioButtonUseTcpService";
            string webServiceUrl = collection["textBoxWebServiceUrl"];

            // the pdf file to convert
            string pdfFilePath = collection["filePathTextBox"][0].Trim();
            if (pdfFilePath.Equals(String.Empty))
                throw new Exception("Please choose a PDF file");

            // start page number
            int startPageNumber = int.Parse(collection["startPageTextBox"][0].Trim());
            // end page number
            // when it is 0 the extraction will continue up to the end of document
            int endPageNumber = 0;
            if (collection["endPageTextBox"][0].Trim() != String.Empty)
                endPageNumber = int.Parse(collection["endPageTextBox"][0].Trim());

            // Create the the PDF images extractor object
            PdfImagesExtractor pdfImagesExtractor = null;
            if (useTcpService)
                pdfImagesExtractor = new PdfImagesExtractor(serverIP, serverPort);
            else
                pdfImagesExtractor = new PdfImagesExtractor(true, webServiceUrl);

            // Set optional service password
            if (useServicePassword)
                pdfImagesExtractor.ServicePassword = servicePassword;

            pdfImagesExtractor.LicenseKey = "mRcGFgMAFgYWABgGFgUHGAcEGA8PDw8WBg==";

            ExtractedImage[] pdfPageImages = null;
            try
            {
                // read the PDF file in a memory buffer
                byte[] sourcePdfBytes = System.IO.File.ReadAllBytes(pdfFilePath);

                // extract the images to an array of ExtractedImage objects
                pdfPageImages = pdfImagesExtractor.ExtractImages(sourcePdfBytes, startPageNumber, endPageNumber);
            }
            catch (Exception ex)
            {
                // The extraction failed
                throw new Exception(String.Format("An error occurred. {0}", ex.Message));
            }

            // return the image extracted from PDF with the largest data
            ExtractedImage largeImage = null;
            for (int i = 0; i < pdfPageImages.Length; i++)
            {
                if (largeImage == null || pdfPageImages[i].ImageData.Length > largeImage.ImageData.Length)
                    largeImage = pdfPageImages[i];
            }

            byte[] imageBytes = largeImage.ImageData;

            FileResult fileResult = new FileContentResult(imageBytes, "image/png");
            fileResult.FileDownloadName = "ExtractedImage.png";

            return fileResult;
        }
    }
}