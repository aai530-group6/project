EVO PDF Client for .NET Core
============================

EVO PDF Client Library for .NET Core can be easily integrated in any application targeting the .NET Core or .NET Standard 2.0 and above to create, read, edit and save PDF documents.

The library includes the HTML to PDF, Word to PDF, Excel to PDF, PDF to Text, PDF to Image, PDF to HTML and PDF Images Extractor components from EVO PDF Toolkit in a single library under an unique namespace that you can access in your .NET applications.
You can see the http://www.evopdf.com/evopdf-client-pdf-library-html-to-pdf.aspx product page for a complete list of library features.

Components and Features
=======================

* HTML to PDF Converter - Creates PDF documents from HTML with advanced support for CSS3, SVG, Web Fonts and JavaScript. The converter can automatically create PDF links, forms, bookmarks and table of contents from HTML tags. You can place the content from multiple HTML documents at any position in PDF pages, headers or footers
* HTML to Image Converter - Creates JPEG, PNG and Bitmap raster images from HTML documents
* HTML to SVG Converter - Creates high quality SVG vector images from HTML documents
* Word to PDF Converter - Creates PDF documents from documents in Word format
* Excel to PDF Converter - Creates PDF documents for the worksheets of an Excel document
* PDF to Image Converter - Takes snapshots of the PDF documents pages having the option to produce a multi-page TIFF image for a selected range of PDF pages 
* PDF to HTML Converter - Converts the PDF pages to HTML documents having the option to produce an index file for a selected range of pages
* PDF to Text Converter - Extracts the text from the PDF pages in original layout from PDF or optimized for reading
* Search text in PDF documents returning the text position in PDF pages. Can be used to highlight a text in a PDF document
* Extract images from PDF keeping the images transparency
* Create PDF documents with text, graphics, images, headers and footers
* Create PDF documents with security features and digital signatures
* Create interactive PDF documents with forms, internal links, text notes and JavaScript actions
* Edit, stamp and merge PDF documents

Compatibility
=============

The client library for .NET Core is compatible with any platform which supports .NET Standard 2.0 or above, including the platforms listed below:

* .NET Core 7, 6, 5, .NET Standard 2.0 , .NET Framework 4.6.2 (and above)
* Windows, Linux, macOS
* Azure, Azure App Service and Azure Functions
* Xamarin for iOS, macOS and Android
* Universal Windows Platform (UWP)
* Web, Console and Desktop applications

Getting Started
===============

Before starting to use the EVO PDF Client for .NET Core in your applications you first have to install the EVO PDF Server.
The server can be installed as Azure Cloud Service Worker Role, Azure Cloud Service Web Role, Azure Service Fabric Application, IIS ASP.NET Web Application or Windows Service. 

EVO PDF Server
--------------

EVO PDF Server can be downloaded from http://www.evopdf.com/download.aspx#client_server page of the website.
EVO PDF Server package contains the server files and detailed installation instructions for each platform.
You can start by installing EVO PDF Server as a Windows Service on the local development machine with default options. In this case the assigned IP address is 127.0.0.1.

After the EVO PDF Server was installed, you are ready to use the EVO PDF Client Library for .NET Core in your applications.

You can quickly start with the demo applications from the Demo folder of this package or you can integrate the library in your own project.

To start with your own project, first add a reference to EvoPdf.Client NuGet package published at https://www.nuget.org/packages/EvoPdf.Client/ . 
Alternatively you can reference the EvoPdfClient_NetCore.dll library directly from the Bin folder.

After the reference to library was added to your project you are now ready to start writing code to convert HTML to PDF in your .NET application.

C# Code Samples
---------------

Copy the C# code lines from the section below to use the HTML to PDF Converter component to create a PDF document from a web page or from a HTML string and save the resulted PDF to a memory buffer for further processing, to a PDF file or send it to browser for download in ASP.NET Core applications.

The server IP address is assigned during server installation and it can be omitted from HtmlToPdfConverter constructor if the server was installed on the localhost IP address 127.0.0.1 .
There are also variants of the constructor accepting an URL instead of IP address if the server was installed as a web service in Azure or in IIS.

At the top of your C# source file add the 'using EvoPdfClient;' statement to make available the EVO PDF Client API for your .NET application.

	// add this using statement at the top of your C# file
	using EvoPdfClient;

To convert a HTML string or an URL to a PDF file you can use the C# code below.

	// create the converter object in your code where you want to run conversion
	// change the serverIP value if the server was installed on a remote machine
	string serverIP = "127.0.0.1";
	HtmlToPdfConverter converter = new HtmlToPdfConverter(serverIP);
	
	// convert the HTML string to a PDF file
	converter.ConvertHtmlToFile("<b>Hello World</b> from EVO PDF !", null, "HtmlToFile.pdf");
	
	// convert HTML page from URL to a PDF file
	string htmlPageURL = "http://www.evopdf.com";
	converter.ConvertUrlToFile(htmlPageURL, "UrlToFile.pdf");

To convert a HTML string or an URL to a PDF document in a memory buffer and then save it to a file you can use the C# code below.

	// create the converter object in your code where you want to run conversion
	// change the serverIP value if the server was installed on a remote machine
	string serverIP = "127.0.0.1";
	HtmlToPdfConverter converter = new HtmlToPdfConverter(serverIP);
	
	// convert a HTML string to a memory buffer
	byte[] htmlToPdfBuffer = converter.ConvertHtml("<b>Hello World</b> from EVO PDF !", null);
	
	// write the memory buffer to a PDF file
	System.IO.File.WriteAllBytes("HtmlToMemory.pdf", htmlToPdfBuffer);
	
	// convert an URL to a memory buffer
	string htmlPageURL = "http://www.evopdf.com";
	byte[] urlToPdfBuffer = converter.ConvertUrl(htmlPageURL);
	
	// write the memory buffer to a PDF file
	System.IO.File.WriteAllBytes("UrlToMemory.pdf", urlToPdfBuffer);

To convert in your ASP.NET Core application a HTML string or an URL to a PDF document in a memory buffer and then send it for download to browser you can use the C# code below.

	// create the converter object in your code where you want to run conversion
	// change the serverIP value if the server was installed on a remote machine
	string serverIP = "127.0.0.1";
	HtmlToPdfConverter converter = new HtmlToPdfConverter(serverIP);
	
	// convert a HTML string to a memory buffer
	byte[] htmlToPdfBuffer = converter.ConvertHtml("<b>Hello World</b> from EVO PDF !", null);
	
	FileResult fileResult = new FileContentResult(htmlToPdfBuffer, "application/pdf");
	fileResult.FileDownloadName = "HtmlToPdf.pdf";
	return fileResult;

Free Trial
==========

This package contains the product binaries, demo Visual Studio projects with full C# code for ASP.NET Core targeting .NET Core 6.0 and later versions, the library documentation in CHM format.

There are separate demo projects for each major component of the library, including HTML to PDF, Word to PDF, Excel to PDF, PDF to Text, PDF to Image, PDF to HTML and PDF Images Extractor.

You can evaluate the library for free as long as it is needed to ensure that the solution fits your application needs.

Important Notes
---------------

If you cannot view the Help.chm or you get errors when running or building the demo applications then this might be an indication that the files were blocked by Windows and you have to unblock them as described below.

Before extracting the downloaded Zip archive it is recommended to unblock the Zip file in case it was blocked by Windows OS and marked as an Internet download. 
To unblock the file, right click the Zip file in Windows Explorer, choose the 'Properties' menu item from contextual menu and enable the Unblock option if this option is displayed in file properties. 
If you extracted the archive without unblocking the Zip file first, you can still unblock the blocked files (the .dll, .chm) individually following the same procedure described for the Zip file.

Licensing
=========

The EVO PDF Software licenses are perpetual which means they never expire for a version of the product and include free maintenance for the first year. You can find more details about licensing in http://www.evopdf.com/buy.aspx page of the website.

The same license keys for EVO PDF software works both with regular libraries for .NET Core and with EVO PDF Client for .NET Core. For example, a license key for EVO PDF Toolkit works with all components from client library, while a license for HTML to PDF Converter will work only with this component of the client library.

Support
=======

For technical and sales questions or for general inquiries about our software and company you can contact us using the email addresses from http://www.evopdf.com/contact.aspx page of the website. 
